<?php
$host = "localhost";
$user = "root";
$password = "";
$database = "irht";
?>
