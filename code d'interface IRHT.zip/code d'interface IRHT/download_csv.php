<?php
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename=data.csv');
$output = fopen('php://output', 'w');


include 'configuration.php'; // Assurez-vous que ce chemin est correct

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Écrivez les en-têtes de colonne
fputcsv($output, array('geonames', 'pays', 'region', 'commune', 'latitude' ,'longitude','object_id' ,'object_value', 'object_type_label', 'type_personnage', 'annee_naissance', 'annee_mort' ));

// Exécutez votre requête SQL pour obtenir les données
$sql = "SELECT geonames,pays,region,commune,latitude,longitude,object_id,object_value,object_type_label,type_personnage,annee_naissance,annee_mort FROM donnees";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($row = $result->fetch_assoc()) {
        fputcsv($output, $row);
    }
}

fclose($output);
$conn->close();
?>
