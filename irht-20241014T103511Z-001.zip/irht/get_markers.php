<?php
header('Content-Type: application/json');

include 'configuration.php'; // Assurez-vous que ce chemin est correct

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die(json_encode(['error' => 'Échec de la connexion : ' . $conn->connect_error]));
}

$sql = "SELECT latitude, longitude, object_type_label, pays, commune, region, geonames, annee_naissance, annee_mort, object_value, lien FROM donnees";
$result = $conn->query($sql);

$markers_data = [];
if ($result->num_rows > 0) {
    while ($row = $result->fetch_assoc()) {
        $markers_data[] = [
            'latitude' => $row['latitude'],
            'longitude' => $row['longitude'],
            'popup' => "Nom : " . $row['object_value'] . "<br>Type de notice : " . $row['object_type_label'] . "<br>Pays: " . $row['pays'] . "<br>Commune: " . $row['commune'] . "<br>Region: " . $row['region'] . "<br>Geonames: " . $row['geonames'] . "<br>Année de Naissance: " . $row['annee_naissance'] . "<br>Année de Mort: " . $row['annee_mort'] . "<br>Lien vers la base : <a href='" . $row['lien'] . "' target='_blank'>" . $row['lien'] . "</a>",
            'annee_naissance' => $row['annee_naissance'],
            'annee_mort' => $row['annee_mort'],
            'object_value' => $row['object_value'],
            'object_type_label' => $row['object_type_label']
        ];
    }
}

$conn->close();
echo json_encode($markers_data);
?>
