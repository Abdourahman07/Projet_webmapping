<?php
include 'configuration.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT MAX(annee_naissance) AS maxYear FROM donnees";
$result = $conn->query($sql);

$maxYear = 2024;

if ($result) {
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $maxYear = (int)$row['maxYear'];
    }
    $result->free();
} else {
    die("Error in query: " . $conn->error);
}

$conn->close();

echo json_encode(['maxYear' => $maxYear]);
?>
