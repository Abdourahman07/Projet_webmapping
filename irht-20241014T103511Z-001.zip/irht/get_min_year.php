<?php
include 'configuration.php';

error_reporting(E_ALL);
ini_set('display_errors', 1);

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT MIN(annee_naissance) AS minYear FROM donnees";
$result = $conn->query($sql);

$minYear = -200;

if ($result) {
    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $minYear = (int)$row['minYear'];
    }
    $result->free();
} else {
    die("Error in query: " . $conn->error);
}

$conn->close();

echo json_encode(['minYear' => $minYear]);
?>
