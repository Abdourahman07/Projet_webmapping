<?php
header('Content-Type: application/json');

include 'configuration.php'; // Assurez-vous que ce chemin est correct

$conn = new mysqli($host, $user, $password, $database);

if ($conn->connect_error) {
    echo json_encode(['error' => 'Échec de la connexion : ' . $conn->connect_error]);
    exit();
}

$sql = "SELECT COUNT(*) as total FROM donnees";
$result = $conn->query($sql);

if (!$result) {
    echo json_encode(['error' => 'Erreur lors de l\'exécution de la requête : ' . $conn->error]);
    exit();
}

$total_count = 0;
if ($result->num_rows > 0) {
    $row = $result->fetch_assoc();
    $total_count = $row['total'];
}

$conn->close();
echo json_encode(['total' => $total_count]);
?>
