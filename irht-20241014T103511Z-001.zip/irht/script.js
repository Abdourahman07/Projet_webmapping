
        var map;
        var markers = [];
        var markersCluster = L.markerClusterGroup({
            disableClusteringAtZoom: 10,
            spiderfyOnMaxZoom: true,
            showCoverageOnHover: false,
            zoomToBoundsOnClick: true,
            iconCreateFunction: function (cluster) {
                var count = cluster.getChildCount();
                var size = 'small';
                if (count >= 10 && count < 50) {
                    size = 'medium';
                } else if (count >= 50) {
                    size = 'large';
                }

                var c = ' marker-cluster-';
                if (count < 10) {
                    c += 'small';
                } else if (count < 100) {
                    c += 'medium';
                } else {
                    c += 'large';
                }

                return new L.DivIcon({
                    html: '<div><span>' + count + '</span></div>',
                    className: 'marker-cluster' + c,
                    iconSize: new L.Point(40, 40)
                });
            }
        });

        var minYear;
        var maxYear;
        var filteredMarkers = [];
        var geojsonLayer;
        var typeColors = {
    "collection": '#e295b5',
    "livre": '#a2bfe8',
    "oeuvre": '#8fd391',
    "personne": '#a4d0db',
    "provenance": '#f3f8de',
    "reluire": '#FF69B4', // Remplacement par rose vif (HotPink)
    "source": '#b8854d',
    "texte": '#cab9e8'
};

        function initializeMap() {
            map = L.map('map').setView([3, 3], 2);

            var openStreetMapLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            }).addTo(map);

            var satelliteLayer = L.tileLayer('https://server.arcgisonline.com/ArcGIS/rest/services/World_Imagery/MapServer/tile/{z}/{y}/{x}', {
                attribution: 'Tiles &copy; Esri &mdash; Source: Esri, i-cubed, USDA, USGS, AEX, GeoEye, Getmapping, Aerogrid, IGN, IGP, UPR-EGP, and the GIS User Community',
                maxZoom: 25
            });
            var landscapeLayer = L.tileLayer('https://{s}.tile.opentopomap.org/{z}/{x}/{y}.png', {
                attribution: 'Map data: © OpenStreetMap contributors, SRTM | Map style: © OpenTopoMap (CC-BY-SA)',
                maxZoom: 17
            });

            var cartoDBPositronLayer = L.tileLayer('https://{s}.basemaps.cartocdn.com/light_all/{z}/{x}/{y}.png', {
                attribution: '&copy; <a href="https://carto.com/attributions">CARTO</a>',
                maxZoom: 20
            });

            var baseLayers = {
                "OpenStreetMap": openStreetMapLayer,
                "Satellite": satelliteLayer,
                "Landscape": landscapeLayer,
                "CartoDB Positron": cartoDBPositronLayer // New layer added here
            };

         // Ajout des calques de superposition pour Francie Occidentale et 100
var overlayLayers = {};

// Chargement du premier GeoJSON pour Francie Occidentale
fetch('france_historique.geojson')
    .then(response => response.json())
    .then(data => {
        var francieLayer = L.geoJSON(data, {
            style: function (feature) {
                return { color: '#ff0000' };
            }
        });
        overlayLayers["Francie Occidentale (843-938)"] = francieLayer;  // Ajout à l'overlayLayers
    })
    .catch(error => console.error('Erreur de chargement de france_historique.geojson:', error));

// Chargement du deuxième GeoJSON pour 1000
fetch('100.geojson')
    .then(response => response.json())
    .then(data => {
        var hundredLayer = L.geoJSON(data, {
            style: function (feature) {
                return { color: '#00ff00' };  // Style de la deuxième couche
            }
        });
        overlayLayers["Frontières (1000)"] = hundredLayer;  // Ajout à l'overlayLayers
    })
    .catch(error => console.error('Erreur de chargement de 100.geojson:', error));
// Chargement du deuxième GeoJSON pour 800
fetch('800.geojson')
    .then(response => response.json())
    .then(data => {
        var hundredLayer = L.geoJSON(data, {
            style: function (feature) {
                return { color: 'grey' };  // Style de la deuxième couche
            }
        });
        overlayLayers["Frontières (800)"] = hundredLayer;  // Ajout à l'overlayLayers
    })
    .catch(error => console.error('Erreur de chargement de 800.geojson:', error));

// Chargement du deuxième GeoJSON pour 1279
fetch('1279.geojson')
    .then(response => response.json())
    .then(data => {
        var hundredLayer = L.geoJSON(data, {
            style: function (feature) {
                return { color: 'grey' };  // Style de la deuxième couche
            }
        });
        overlayLayers["Frontières (1279)"] = hundredLayer;  // Ajout à l'overlayLayers
    })
    .catch(error => console.error('Erreur de chargement de 1279.geojson:', error));
// Chargement du deuxième GeoJSON pour 1492
fetch('1492.geojson')
    .then(response => response.json())
    .then(data => {
        var hundredLayer = L.geoJSON(data, {
            style: function (feature) {
                return { color: 'grey' };  // Style de la deuxième couche
            }
        });
        overlayLayers["Frontières (1492)"] = hundredLayer;  // Ajout à l'overlayLayers
    })
    .catch(error => console.error('Erreur de chargement de 1492.geojson:', error));
// Chargement du deuxième GeoJSON pour 1530
fetch('1530.geojson')
    .then(response => response.json())
    .then(data => {
        var hundredLayer = L.geoJSON(data, {
            style: function (feature) {
                return { color: 'grey' };  // Style de la deuxième couche
            }
        });
        overlayLayers["Frontières (1530)"] = hundredLayer;  // Ajout à l'overlayLayers
    })
    .catch(error => console.error('Erreur de chargement de 1530.geojson:', error));

// Attendre que les deux fetchs soient terminés avant d'ajouter les couches à la carte
Promise.all([
    fetch('france_historique.geojson').then(response => response.json()),
    fetch('100.geojson').then(response => response.json()),
    fetch('800.geojson').then(response => response.json()),
    fetch('1279.geojson').then(response => response.json()),
    fetch('1492.geojson').then(response => response.json()),
    fetch('1530.geojson').then(response => response.json())
]).then(() => {
    L.control.layers(baseLayers, overlayLayers).addTo(map);
}).catch(error => console.error('Erreur lors de la configuration des calques:', error));



            var miniMapLayer = L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
                attribution: '&copy; OpenStreetMap contributors'
            });

            var miniMap = new L.Control.MiniMap(miniMapLayer).addTo(map);
            L.control.scale().addTo(map);
        }
        

        function fetchMarkers() {
            fetch('get_markers.php')
                .then(response => response.json())
                .then(data => {
                    markers = data;
                    populateFilters();
                    applyFilters();
                })
                .catch(error => {
                    console.error('Error fetching marker data:', error);
                    showError('Erreur lors de la récupération des données des marqueurs.');
                });
        }

        function fetchTotalCount() {
            fetch('get_total_count.php')
                .then(response => response.json())
                .then(data => document.getElementById('total-data').innerText = data.total.toLocaleString())
                .catch(error => {
                    console.error('Error fetching total count:', error);
                    showError('Erreur lors de la récupération du nombre total de notices.');
                });
        }

        function populateFilters() {
            var countryFilter = document.getElementById('country-filter');
            var objectTypeFilter = document.getElementById('object-type-filter');

            var countries = new Set();
            var objectTypes = new Set();

            countryFilter.innerHTML = '<option value="">Tous</option>';
            objectTypeFilter.innerHTML = '<option value="">Tous</option>';

            markers.forEach(function (marker) {
                countries.add(marker.popup.split('<br>')[2].split(': ')[1]);
                objectTypes.add(marker.popup.split('<br>')[1].split(': ')[1]);
            });

            countries.forEach(function (country) {
                var option = document.createElement('option');
                option.value = country;
                option.textContent = country;
                countryFilter.appendChild(option);
            });

            objectTypes.forEach(function (objectType) {
                var option = document.createElement('option');
                option.value = objectType;
                option.textContent = objectType;
                objectTypeFilter.appendChild(option);
            });
        }

        function getColorForType(type) {
    return typeColors[type] || '#D4E157'; // Si le type n'existe pas, retourne rouge par défaut
}

        function createColoredIcon(color) {
            return L.divIcon({
                className: 'custom-div-icon',
                html: `<svg xmlns="http://www.w3.org/2000/svg" width="32" height="32" viewBox="0 0 24 24" fill="${color}" stroke="black" stroke-width="1" stroke-linecap="round" stroke-linejoin="round" class="feather feather-map-pin"><path d="M21 10c0 5-9 13-9 13S3 15 3 10a9 9 0 1 1 18 0z"></path><circle cx="12" cy="10" r="3"></circle></svg>`,
                iconSize: [32, 32],
                iconAnchor: [16, 32],
                popupAnchor: [1, -32],
                shadowSize: [41, 41]
            });
        }
        function updateColors() {
    filteredMarkers.forEach(function (marker) {
        var type = marker.popup.split('<br>')[1].split(': ')[1];
        var color = getColorForType(type);
        // Ici, mettez à jour la couleur de l'élément concerné
        var leafletMarker = L.marker([marker.latitude, marker.longitude], { icon: createColoredIcon(color) });
        markersCluster.addLayer(leafletMarker);
    });
    map.addLayer(markersCluster);
}


        function updateMarkers(minYear, maxYear, selectedCountry, selectedObjectType, searchName) {
            markersCluster.clearLayers();

            filteredMarkers = markers.filter(function (marker) {
                return marker.annee_naissance <= maxYear && marker.annee_mort >= minYear &&
                    (selectedCountry === "" || marker.popup.includes(selectedCountry)) &&
                    (selectedObjectType === "" || marker.popup.includes(selectedObjectType)) &&
                    (searchName === "" || marker.popup.toLowerCase().includes(searchName));
            });

            filteredMarkers.forEach(function (marker) {
                var type = marker.popup.split('<br>')[1].split(': ')[1];
                var color = getColorForType(type);
                var icon = createColoredIcon(color);
                var leafletMarker = L.marker([marker.latitude, marker.longitude], { icon: icon }).bindPopup(marker.popup);
                markersCluster.addLayer(leafletMarker);
            });

            map.addLayer(markersCluster);
            updateTotalFilteredCount();
        }

        function updateTotalFilteredCount() {
            var totalFilteredCount = filteredMarkers.length;
            document.getElementById('total-data').innerText = totalFilteredCount.toLocaleString();
        }

        var ctx = document.getElementById('myChart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'pie',
            data: {
                labels: [],
                datasets: [{
                    data: [],
                    backgroundColor: []
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    },
                    tooltip: {
                        callbacks: {
                            label: function (context) {
                                var label = context.label || '';
                                if (label) {
                                    label += ': ';
                                }
                                if (context.parsed !== null) {
                                    label += new Intl.NumberFormat().format(context.parsed);
                                }
                                return label;
                            }
                        }
                    },
                    datalabels: {
                        anchor: 'end',
                        align: 'end',
                        offset: function(context) {
                            if (context.element) {
                                var angle = context.element.startAngle + ((context.element.endAngle - context.element.startAngle) / 2);
                                if (angle >= Math.PI / 2 && angle <= (3 * Math.PI) / 2) {
                                    return 30;
                                }
                                return 20;
                            }
                            return 20;
                        },
                        formatter: function(value, context) {
                            return context.chart.data.labels[context.dataIndex] + ' ' + value.toLocaleString();
                        },
                        color:'#333', // Change the text color to white
                        backgroundColor: function (context) {
                            return context.dataset.backgroundColor[context.dataIndex];
                        },
                        borderColor: function (context) {
                            return context.dataset.backgroundColor[context.dataIndex];
                        },
                        borderWidth: 1,
                        borderRadius: 4,
                        padding: 6,
                        textAlign: 'center',
                        font: {
                            size: 12,
                            weight: 'bold'
                        },
                        clip: false,
                        display: function(context) {
                            var dataset = context.dataset;
                            var count = dataset.data.length;
                            var value = dataset.data[context.dataIndex];
                            return value > 0; // Display only if value is greater than 0
                        }
                    }
                },
                onClick: function(evt, element) {
                    if (element.length > 0) {
                        var clickedElementIndex = element[0].index;
                        var label = myChart.data.labels[clickedElementIndex];
                        filterByChart(label);
                    }
                },
                onDblClick: function() {
                    resetFilters();
                }
            },
            plugins: [ChartDataLabels]
        });

        // Add event listener for double click on the chart
        document.getElementById('myChart').addEventListener('dblclick', resetFilters);

        function resetFilters() {
            document.getElementById('country-filter').value = "";
            document.getElementById('object-type-filter').value = "";
            document.getElementById('name-filter').value = "";
            
            if (slider && slider.noUiSlider) {
                slider.noUiSlider.set([minYear, maxYear]);
            }

            applyFilters();
        }

        function filterByChart(clickedLabel) {
            var selectedCountry = document.getElementById('country-filter').value;
            var searchName = document.getElementById('name-filter').value.toLowerCase();
            var slider = document.getElementById('slider');

            if (slider && slider.noUiSlider) {
                var sliderValues = slider.noUiSlider.get();
                var minYear = parseInt(sliderValues[0]);
                var maxYear = parseInt(sliderValues[1]);

                updateMarkers(minYear, maxYear, selectedCountry, clickedLabel, searchName);
                updateChart(minYear, maxYear, selectedCountry, clickedLabel, searchName);
                updateTotalFilteredCount();
            } else {
                console.error('Slider is not initialized.');
            }
        }

        function updateChart(minYear, maxYear, selectedCountry, selectedObjectType, searchName) {
            var filteredMarkers = markers.filter(function (marker) {
                return marker.annee_naissance <= maxYear && marker.annee_mort >= minYear &&
                    (selectedCountry === "" || marker.popup.includes(selectedCountry)) &&
                    (selectedObjectType === "" || marker.popup.includes(selectedObjectType)) &&
                    (searchName === "" || marker.popup.toLowerCase().includes(searchName));
            });

            var typeCounts = {};
            filteredMarkers.forEach(function (marker) {
                var type = marker.popup.split('<br>')[1].split(': ')[1];
                if (!typeCounts[type]) {
                    typeCounts[type] = 0;
                }
                typeCounts[type]++;
            });

            var labels = Object.keys(typeCounts);
            var data = Object.values(typeCounts);

            var combined = labels.map((label, index) => ({ label, count: data[index] }));
            combined.sort((a, b) => b.count - a.count);

            labels = combined.map(item => item.label);
            data = combined.map(item => item.count);

            var backgroundColors = labels.map(label => getColorForType(label));

            myChart.data.labels = labels;
            myChart.data.datasets[0].data = data;
            myChart.data.datasets[0].backgroundColor = backgroundColors;
            myChart.update();
        }



        function applyFilters() {
            var selectedCountry = document.getElementById('country-filter').value;
            var selectedObjectType = document.getElementById('object-type-filter').value;
            var searchName = document.getElementById('name-filter').value.toLowerCase();
            var slider = document.getElementById('slider');

            if (slider && slider.noUiSlider) {
                var sliderValues = slider.noUiSlider.get();
                var minYear = parseInt(sliderValues[0]);
                var maxYear = parseInt(sliderValues[1]);

                updateMarkers(minYear, maxYear, selectedCountry, selectedObjectType, searchName);
                updateChart(minYear, maxYear, selectedCountry, selectedObjectType, searchName);
                updateTotalFilteredCount();
            } else {
                console.error('Slider is not initialized.');
            }
        }

        function applyTemporalSelection() {
            var startYear = parseInt(document.getElementById('start-year').value) || minYear;
            var endYear = parseInt(document.getElementById('end-year').value) || maxYear;
            var slider = document.getElementById('slider');

            if (slider && slider.noUiSlider) {
                slider.noUiSlider.set([startYear, endYear]);
            } else {
                console.error('Slider is not initialized.');
            }
        }

        function fetchMinYear() {
            return fetch('get_min_year.php')
                .then(response => response.json())
                .then(data => {
                    return data.minYear;
                })
                .catch(error => {
                    console.error('Error fetching min year:', error);
                    showError('Erreur lors de la récupération de l\'année minimale.');
                });
        }

        function fetchMaxYear() {
            return fetch('get_max_year.php')
                .then(response => response.json())
                .then(data => {
                    return data.maxYear;
                })
                .catch(error => {
                    console.error('Error fetching max year:', error);
                    showError('Erreur lors de la récupération de l\'année maximale.');
                });
        }

        async function initializeSlider() {
            try {
                minYear = await fetchMinYear();
                maxYear = await fetchMaxYear();

                var slider = document.getElementById('slider');
                noUiSlider.create(slider, {
                    start: [minYear, maxYear],
                    connect: true,
                    range: {
                        'min': minYear,
                        'max': maxYear
                    },
                    step: 1,
                    tooltips: [true, true],
                    format: {
                        to: function (value) {
                            return parseInt(value);
                        },
                        from: function (value) {
                            return parseInt(value);
                        }
                    }
                });
    slider.noUiSlider.on('update', function (values, handle) {
    let tooltips = document.querySelectorAll('.noUi-tooltip');
    let value0 = parseInt(values[0]);
    let value1 = parseInt(values[1]);

    if (value0 === value1) {
        tooltips[0].style.transform = ''; // Réinitialise les transformations
        tooltips[1].style.transform = ''; 
    } else if (Math.abs(value1 - value0) < 10) {  // Ajustez ce seuil en fonction de vos besoins
        tooltips[0].style.transform = 'translateX(-100%)';
        tooltips[1].style.transform = 'translateX(100%)';
    } else {
        tooltips[0].style.transform = '';
        tooltips[1].style.transform = '';
    }
});



                slider.noUiSlider.on('update', debounce(applyFilters, 300));
                document.getElementById('country-filter').addEventListener('change', debounce(applyFilters, 300));
                document.getElementById('object-type-filter').addEventListener('change', debounce(applyFilters, 300));
                document.getElementById('name-filter').addEventListener('input', debounce(applyFilters, 300));

            } catch (error) {
                console.error('Error initializing slider:', error);
            }
        }

        function downloadCSV() {
            window.location.href = 'download_csv.php';
        }

        function printMap() {
            window.print();
        }

        function showError(message) {
            alert(message);
        }

        function debounce(func, delay) {
            let debounceTimer;
            return function () {
                const context = this;
                const args = arguments;
                clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => func.apply(context, args), delay);
            };
        }

        document.addEventListener('DOMContentLoaded', function () {
            initializeMap();
            fetchMarkers();
            fetchTotalCount();
            initializeSlider();
            openWelcomeModal();
        });

        function openHelpModal() {
            document.getElementById('helpModal').style.display = 'block';
        }

        function closeHelpModal() {
            document.getElementById('helpModal').style.display = 'none';
        }

        function openWelcomeModal() {
            document.getElementById('welcomeModal').style.display = 'block';
        }

        function closeWelcomeModal() {
            document.getElementById('welcomeModal').style.display = 'none';
        }

        window.onclick = function(event) {
            var welcomeModal = document.getElementById('welcomeModal');
            var helpModal = document.getElementById('helpModal');
            if (event.target == welcomeModal) {
                welcomeModal.style.display = 'none';
            }
            if (event.target == helpModal) {
                helpModal.style.display = 'none';
            }
        }
 